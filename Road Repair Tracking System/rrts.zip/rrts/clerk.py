from constants import *
from resident import *
class Clerk:
	def __init__(self, requesterName=None, requesterAddress=None, requesterContact=None, requesterIDNumber=None):
		self.requester = Resident(requesterName, requesterAddress, requesterContact, requesterIDNumber) if requesterName else None
	
	def request_raiser(self, location, startPoint, endPoint):
		requestID = -1
		activeRequests = -1
		priority = -1

		rawMaterials, machinesRequired, personnelRequired = [''] * 3
		
		with open(REQUESTIDPATH, 'r') as f:
			requestID = int(f.read())

		with open(REQUESTIDPATH, 'w') as f:
			f.write(str(requestID + 1))

		try:
			with open(DATAPATH, 'a') as f:
				f.write(','.join(map(str, [requestID+1, location, startPoint, endPoint, self.requester.residentName, self.requester.address, self.requester.contact, self.requester.IDNumber, priority, rawMaterials, machinesRequired, personnelRequired])) + '\n')
				print(f"Request ID: {requestID+1}")

		except:
			print("Error opening file while raising request by resident.")
			return 1

		return 0