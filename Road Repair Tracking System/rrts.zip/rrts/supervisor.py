from constants import *
import os

class Supervisor:
	def __init__(self):
		pass

	def enter_information(self, requestID, newPriority, newRawMaterials, newMachinesRequired, newPersonnelRequired):
		try:
			with open(DATAPATH, 'r') as fin, open(TEMPDATAPATH, 'w') as fout:
				for line in fin:
					temp = line.split(',')
					if int(temp[0]) == requestID:
						fout.write(','.join(temp[:8] + [newPriority, newRawMaterials, newMachinesRequired, newPersonnelRequired]) + '\n')
					else:
						fout.write(line)
				print("Values updated successfully!!!")
		except:
			print("Error opening file while updating information by supervisor")
			return 1
		os.remove(DATAPATH)
		os.rename(TEMPDATAPATH, DATAPATH)
		return 0

	def repair_scheduler(self):
		with open(DATAPATH, 'r') as f:
			lines = f.read().split('\n')[:-1]
			lines = sorted(lines, key=lambda line: int(line.split(',')[8]), reverse=True)

		print("\nData format: <Request ID> <Location> <Start Point> <End Point> <Name> <Address> <Contact> <ID Numbe> <Priority> <Required Raw Materials> <Required Machines> <Required Personnels>\n")
		for line in lines:
			print(line)

		with open(DATAPATH, 'w') as f:
			f.write('\n'.join(lines) + '\n')

	def enter_statistics(self):
		with open(STATISTICSPATH, 'w') as f:
			repairOverTime = input("Enter repair work over time: ")
			repairOutstanding = input("Enter repair work outstanding: ")
			repairUtilization = input("Enter repair utilization: ")
			f.write('\n'.join([repairOverTime, repairOutstanding, repairUtilization]) + '\n')
			print("Values updated successfully by supervisor!!")
			