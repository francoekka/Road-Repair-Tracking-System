from resident import *
from clerk import *
from supervisor import *
from mayor import *
from administrator import *


def resident_driver():
	print("\nRaise request for road repair by resident.")
	location = input("Enter Location: ")
	startPoint = input("Enter start point of road: ")
	endPoint = input("Enter end point of road: ")
	residentName = input("Enter your name: ")
	address = input("Enter your address: ")
	contact = input("Enter your contact number: ")
	IDNumber = input("Enter your IDNumber: ")

	r = Resident(residentName, address, contact, IDNumber)
	if r.request_raiser(location, startPoint, endPoint) == 0:
		print("Request Raised successfully by resident !!")
		return 0
	else:
		return 1

def clerk_driver():
	print("\nRaise request for road repair by clerk.")
	location = input("Enter Location: ")
	startPoint = input("Enter start point of road: ")
	endPoint = input("Enter end point of road: ")
	requesterName = input("Enter resident's name: ")
	requesterAddress = input("Enter resident's address: ")
	requesterContact = input("Enter resident's contact number: ")
	requesterIDNumber = input("Enter resident's IDNumber: ")

	r = Clerk(requesterName, requesterAddress, requesterContact, requesterIDNumber)
	if r.request_raiser(location, startPoint, endPoint) == 0:
		print("Request Raised successfully by clerk !!")
		return 0
	else:
		return 1

def supervisor_driver():
	newRawMaterials, newMachinesRequired, newPersonnelRequired = [''] * 3
	s = Supervisor()
	print("\nSupervisor")
	print("----------")
	print("1. Enter information about a road repair request.\n2. Schedule road repair work\n3. Enter Statistics\n")

	option = int(input())
	if option==1:
		print("\nNow entering information about road repair request...")
		requestID = int(input("Enter request ID whose values have to be updated: "))
		newPriority = input("Enter new priority(1-100): ")
		newRawMaterials = input("Enter new raw materials: ")
		newMachinesRequired =  input("Enter new machines required: ")
		newPersonnelRequired = input("Enter new personnel required: ")
		return s.enter_information(requestID, newPriority, newRawMaterials, newMachinesRequired, newPersonnelRequired)
	elif option==2:
		print("Now scheduling road repairs...")
		return s.repair_scheduler()
	elif option==3:
		return s.enter_statistics()


def administrator_driver():
	print("\nAdministrator")
	print("-------------")
	print("Enter information about the available resources")

	a = Administrator()
	manpower = input("Enter available manpower with the system: ")
	machines = input("Enter available machines with the system: ")
	return a.enter_available_resources(manpower, machines);


def mayor_driver():
	m = Mayor()
	print("Mayor")
	print("-----")
	print("Query Repair Statistics.")
	m.query_repair_statistics()

def main_interface():
	print("---------------------------")
	print("---------------------------")
	print("Road Repair Tracking System")
	print("---------------------------")
	print("---------------------------")
	option = None
	while option != '6':
		print("Please choose your identity:")
		print("1. Resident")
		print("2. Clerk")
		print("3. Supervisor")
		print("4. Administrator")
		print("5. Mayor")
		print("6. Exit")
		print("\nEnter user :- ", end='')
		option = input()
		if option < '0' or option > '6':
			print("Please choose correctly.")
			continue
		elif (option=='1'):		return resident_driver()		# Resident
		elif (option=='2'):		return clerk_driver()			# Clerk
		elif (option=='3'):		return supervisor_driver()		# Supervisor
		elif (option=='4'):		return administrator_driver()	# Administrator
		elif (option=='5'):		return mayor_driver()			# Mayor

def main():
	print("    Road Repair Tracking System  ")
	return main_interface()

if __name__ == '__main__':
	main()
