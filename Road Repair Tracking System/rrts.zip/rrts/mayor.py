from constants import *
class Mayor:
	def __init__(self):
		pass

	def query_repair_statistics(self):
		with open(STATISTICSPATH, 'r') as f:
			repairOverTime, repairOutstanding, repairUtilization = f.read().split('\n')[:-1]
			print(f"Repair work over time: {repairOverTime}")
			print(f"Repair work outstanding: {repairOutstanding}")
			print(f"Repair utilization: {repairUtilization}")