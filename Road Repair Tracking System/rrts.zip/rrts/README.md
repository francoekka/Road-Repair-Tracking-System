## Synopsis

Road Repair Tracking System for Software Engineering Course Fall 2018 at IIIT Bhubaneswar.

## Running

Navigate using commandline to this directory in which the README.md is present.

Then, execute the following to run the project:

```Bash
python3 rrts.py
```

