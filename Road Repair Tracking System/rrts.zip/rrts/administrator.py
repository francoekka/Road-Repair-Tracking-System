from supervisor import *

class Administrator:
	def __init__(self):
		pass

	def enter_available_resources(self, manpower, machines):
		with open(RESOURCESPATH, 'w') as f:
			f.write('\n'.join([manpower, machines]) + '\n')
			print("Available resources updated successfully !!")